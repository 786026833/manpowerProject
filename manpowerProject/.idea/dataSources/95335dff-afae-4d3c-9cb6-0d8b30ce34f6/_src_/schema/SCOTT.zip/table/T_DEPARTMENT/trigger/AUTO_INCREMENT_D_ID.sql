CREATE TRIGGER AUTO_INCREMENT_D_ID
BEFORE INSERT
  ON T_DEPARTMENT
FOR EACH ROW
  DECLARE
    new_id number;
    BEGIN 
    SELECT T_DEPARTMENT_SEQ.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.D_ID:=new_id;
  END;
/
