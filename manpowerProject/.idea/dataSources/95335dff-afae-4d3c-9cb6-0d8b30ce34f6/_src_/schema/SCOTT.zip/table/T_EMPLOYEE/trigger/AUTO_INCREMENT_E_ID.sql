CREATE TRIGGER AUTO_INCREMENT_E_ID
BEFORE INSERT
  ON T_EMPLOYEE
FOR EACH ROW
  DECLARE
    new_id number;
    BEGIN 
    SELECT T_EMPLOYEE_SEQ.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.E_ID:=new_id;
  END;
/
