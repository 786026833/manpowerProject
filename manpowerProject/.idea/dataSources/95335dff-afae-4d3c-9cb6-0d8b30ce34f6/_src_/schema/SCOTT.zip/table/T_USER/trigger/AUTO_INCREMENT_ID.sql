CREATE TRIGGER AUTO_INCREMENT_ID
BEFORE INSERT
  ON T_USER
FOR EACH ROW
  DECLARE
    new_id number;
    BEGIN 
    SELECT t_user_seq.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.U_ID:=new_id;
  END;
/
