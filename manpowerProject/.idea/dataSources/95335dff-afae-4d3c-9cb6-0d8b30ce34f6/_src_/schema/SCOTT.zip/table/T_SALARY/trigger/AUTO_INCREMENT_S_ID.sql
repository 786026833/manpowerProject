CREATE TRIGGER AUTO_INCREMENT_S_ID
BEFORE INSERT
  ON T_SALARY
FOR EACH ROW
  DECLARE
    new_id number;
    BEGIN 
    SELECT T_SALARY_SEQ.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.S_ID:=new_id;
  END;
/
