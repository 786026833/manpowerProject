CREATE TRIGGER AUTO_INCREMENT_RD_ID
BEFORE INSERT
  ON T_RESUME_DD
FOR EACH ROW
  DECLARE
    new_id number;
  BEGIN
    SELECT T_RESUME_DD_seq.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.RD_ID:=new_id;
  END;
/
