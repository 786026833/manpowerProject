CREATE TRIGGER AUTO_INCREMENT_R_ID
BEFORE INSERT
  ON T_RESUME
FOR EACH ROW
  DECLARE
    new_id number;
  BEGIN
    SELECT T_RESUME_SEQ.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.R_ID:=new_id;
  END;
/
