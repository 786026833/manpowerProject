CREATE TRIGGER AUTO_INCREMENT_T_ID
BEFORE INSERT
  ON T_TRAIN
FOR EACH ROW
  DECLARE
    new_id number;
    BEGIN 
    SELECT T_TRAIN_SEQ.nextval INTO new_id/*t_user_seq 是表的序列函数*/
    FROM dual;
    :NEW.T_ID:=new_id;
  END;
/
